/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Project;

import java.sql.*;
/**
 *
 * @author Bs589TU
 */
public class Connectiondb {


    public static Connection getcn() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   
    
    
    Connection cn;
    Statement st;
    ResultSet res;
   
           try{
               
               Class.forName("com.mysql.jdbc.Driver");
               cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/myclinic","root","");
               st=cn.createStatement();
               System.out.println("connected");
               return cn;
               
                  
           }
           
                   catch (Exception ex) {
                       System.out.println("disConnected"+ex);
                       return null;
        }
           
    }
    }

